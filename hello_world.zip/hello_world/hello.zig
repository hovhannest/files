const std = @import("std");
const log = @import("logger.zig");

pub fn main() void {
    const me = "Hello World";
    std.debug.print("{s}\n", .{me});

    const log_level = log.LogLevel.Info;
    var logger = log.create_logger(log_level).init(log_level);

    logger.debug("This is a debug message");
    logger.info("This is an info message");
    logger.warning("This is a warning message");
    logger.err("This is an error message");
}
