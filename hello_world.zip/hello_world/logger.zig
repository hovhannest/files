const std = @import("std");

pub const LogLevel = enum(u8) {
    Debug,
    Info,
    Warning,
    Error,
    None,
};

pub const Logger = struct {
    log_level: LogLevel,

    pub fn init(log_level: LogLevel) Logger {
        return Logger{ .log_level = log_level };
    }

    // Function to check if the current log level allows logging at the given level
    fn is_loggable(self: *Logger, level: LogLevel) bool {
        return @intFromEnum(level) >= @intFromEnum(self.log_level);
    }

    pub fn log(self: *Logger, level: LogLevel, message: []const u8) void {
        if (self.is_loggable(level)) {
            const prefix = switch (level) {
                LogLevel.Debug => "DEBUG: ",
                LogLevel.Info => "INFO: ",
                LogLevel.Warning => "WARNING: ",
                LogLevel.Error => "ERROR: ",
                LogLevel.None => "None: ",
            };
            std.debug.print("{s}{s}\n", .{ prefix, message });
        }
    }

    pub fn debug(self: *Logger, message: []const u8) void {
        if (self.is_loggable(LogLevel.Debug)) {
            self.log(LogLevel.Debug, message);
        }
    }

    pub fn info(self: *Logger, message: []const u8) void {
        if (self.is_loggable(LogLevel.Info)) {
            self.log(LogLevel.Info, message);
        }
    }

    pub fn warning(self: *Logger, message: []const u8) void {
        if (self.is_loggable(LogLevel.Warning)) {
            self.log(LogLevel.Warning, message);
        }
    }

    pub fn err(self: *Logger, message: []const u8) void {
        if (self.is_loggable(LogLevel.Error)) {
            self.log(LogLevel.Error, message);
        }
    }
};

// NoOpLogger struct that implements the same interface as Logger
pub const NoOpLogger = struct {
    pub fn init(_: LogLevel) NoOpLogger {
        return NoOpLogger{};
    }

    pub fn log(_: *NoOpLogger, _: LogLevel, _: []const u8) void {
        // No-op: do nothing
    }

    pub fn debug(_: *NoOpLogger, _: []const u8) void {
        // No-op: do nothing
    }

    pub fn info(_: *NoOpLogger, _: []const u8) void {
        // No-op: do nothing
    }

    pub fn warning(_: *NoOpLogger, _: []const u8) void {
        // No-op: do nothing
    }

    pub fn err(_: *NoOpLogger, _: []const u8) void {
        // No-op: do nothing
    }
};

// Factory function to create a logger based on the log level
pub fn create_logger(log_level: LogLevel) type {
    if (log_level == LogLevel.None) {
        return NoOpLogger;
    } else {
        return Logger;
    }
}
