const std = @import("std");
//pub const std_options: std.Options = .{ .keep_sigpipe = true };

const logger = @import("foo");

pub fn foo() void {
    const me = "Hello Foo";
    std.debug.print("{s}\n", .{me});
}
