const std = @import("std");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const exe = b.addExecutable(.{
        .name = "hello",
        .root_source_file = b.path("hello.zig"),
        .target = target,
        .optimize = optimize,
        .omit_frame_pointer = true,
        .code_model = .small,
        .linkage = .static,
        .single_threaded = true,
        .sanitize_thread = false,
        .unwind_tables = false, // Do we need this?
    });

    exe.compress_debug_sections = .zstd;
    b.installArtifact(exe);
}
